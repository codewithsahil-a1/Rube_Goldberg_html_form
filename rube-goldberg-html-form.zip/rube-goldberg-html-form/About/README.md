# Rube Goldberg HTML form

A Pen created on CodePen.

For Execution, you need to open index.html which is in the dist name folder -- Sahil

insta URL : [ https://www.instagram.com/code_sahil.in?igsh=Y255OGp2bXVmeWUz ]

Original URL: [https://codepen.io/ksenia-k/pen/xxoqXbJ](https://codepen.io/ksenia-k/pen/xxoqXbJ).

